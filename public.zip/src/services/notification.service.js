// Simple Firestore notifications used by mentions & assignee changes
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { db } from "../core/firebase";

/**
 * Write one doc under /projects/{pid}/notifications
 */
export async function createNotification(pid, payload) {
  const col = collection(db, "projects", pid, "notifications");
  await addDoc(col, {
    ...payload,
    read: false,
    createdAt: serverTimestamp(),
  });
}

/**
 * Mention notifications: toUids = array of member UIDs
 */
export async function notifyMentions({ pid, taskId, toUids = [], byUid }) {
  const jobs = toUids.map((toUid) =>
    createNotification(pid, { type: "mention", taskId, toUid, byUid })
  );
  await Promise.all(jobs);
}

/**
 * Assignment notification: one target
 */
export async function notifyAssignment({ pid, taskId, toUid, byUid }) {
  if (!toUid || toUid === byUid) return;
  await createNotification(pid, { type: "assignment", taskId, toUid, byUid });
}
