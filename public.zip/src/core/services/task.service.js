// minimal, drop-in watcher with error callback + guard
import { collection, onSnapshot, orderBy, query } from "firebase/firestore";
import { db } from "../firebase";            // ← keep your path
import { toast } from "react-toastify";

export function watchTasks(projectId, onChange) {
  if (!projectId) {
    console.warn("[tasks] start skipped: missing projectId");
    return () => {};
  }

  const col = collection(db, "projects", projectId, "tasks");
  const q = query(col, orderBy("order", "desc"));

  const unsub = onSnapshot(
    q,
    (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      onChange(list);
    },
    (err) => {
      // Never crash; explain what failed
      console.warn("[tasks watch error]", { projectId, code: err.code, msg: err.message });
      if (err.code === "permission-denied") {
        toast.error("You don’t have permission to view tasks for this project.");
      } else {
        toast.error(`Tasks error: ${err.message}`);
      }
    }
  );

  return unsub;
}
