import { create } from "zustand";
import { watchTasks } from "../core/services/task.service";

export const useTaskStore = create((set, get) => {
  let unsub = null;

  return {
    tasks: [],
    start: (pid) => {
      // avoid duplicate/invalid listeners
      if (!pid) { console.warn("[task.store] no pid"); return; }
      get().stop();
      unsub = watchTasks(pid, (list) => set({ tasks: list }));
    },
    stop: () => {
      if (unsub) { try { unsub(); } catch {} finally { unsub = null; }
      }
      set({ tasks: [] });
    }
  };
});
