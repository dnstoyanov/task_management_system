import { useAuthStore } from "../../stores/useAuthStore";
import { Bell } from "lucide-react";

function Avatar({ user }) {
  const letter =
    (user?.displayName || user?.email || "?").trim().charAt(0).toUpperCase() || "?";
  if (user?.photoURL) {
    return <img src={user.photoURL} alt="User avatar" className="w-8 h-8 rounded-full object-cover" />;
  }
  return (
    <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-xs font-semibold">
      {letter}
    </div>
  );
}

export default function AppShell({ children, onNewProject, onManageMembers }) {
  const { user, logout } = useAuthStore();

  return (
    <div className="min-h-screen">
      <header className="flex items-center justify-between p-4 border-b bg-white">
        <h1 className="text-xl font-bold">Task Management</h1>

        <div className="flex items-center gap-3">
          {onManageMembers && (
            <button
              onClick={onManageMembers}
              className="px-3 py-1 bg-blue-600 text-white font-semibold rounded border"
            >
              + Members
            </button>
          )}

          {onNewProject && (
            <button
              onClick={onNewProject}
              className="px-3 py-1 rounded bg-blue-600 text-white"
            >
              New Project
            </button>
          )}

          {/* separator */}
          <div className="h-6 w-px bg-gray-200 mx-1" />

          {/* simple bell icon (placeholder for notif tray) */}
          <button title="Notifications" aria-label="Notifications" className="p-2 rounded border hover:bg-gray-50">
            <Bell size={16} />
          </button>

          {/* separator */}
          <div className="h-6 w-px bg-gray-200 mx-1" />

          <div className="flex items-center gap-2">
            <Avatar user={user} />
            <span className="text-sm text-gray-700">{user?.email || user?.displayName}</span>

            {/* separator matching the one before */}
            <div className="h-6 w-px bg-gray-200 mx-1" />

            <button
              onClick={logout}
              title="Logout"
              aria-label="Logout"
              className="px-3 py-1 rounded border bg-gray-100 text-gray-700 hover:bg-gray-200"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="p-6">{children}</main>
    </div>
  );
}
